#pragma once
#include "subprojects\std_lib_facilities\std_lib_facilities.h"

class Test{
public:
    void testRank();
    void testCard();
    static void testPrintCardDeck();
    void testCardDeck();
};